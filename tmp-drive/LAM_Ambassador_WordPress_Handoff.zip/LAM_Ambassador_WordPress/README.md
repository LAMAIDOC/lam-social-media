# LAM Ambassador Program: WordPress handoff

Three pages for littleangelmedical.com. Each page is a single self-contained HTML snippet (markup + scoped CSS + small script) that can be pasted into one WPBakery **Raw HTML** element. Everything is scoped under `.lam-amb`, so it won't affect the rest of the site, and the theme's own header and footer stay in place.

`preview.html` is the approved design as one file (open it in a browser to see how the pages should look and behave on desktop and mobile).

## Files

| File | Page | Suggested URL |
|---|---|---|
| `1-ambassador-page.html` | Landing page (hero, why partner, why parents love LAM, earnings calculator, how it works, FAQ) | `/ambassadors/` |
| `2-apply-page.html` | Application form + confirmation message | `/ambassadors/apply/` |
| `3-terms-page.html` | Ambassador Program Terms and Conditions | `/ambassadors/terms/` |
| `images/` | Logo files: `lam-logo-mark.png` and `lam-logo-full.png` are used by the pages; `lam-logo-horizontal.png` is the correct horizontal logo for the site header | upload to `/wp-content/uploads/lam-ambassadors/` |
| `LAM_Ambassador_Program_Terms.docx` | The terms in Word format, copied word for word from the master terms Google Doc. The terms page text matches it. | n/a |
| `preview.html` | Reference preview of the finished design | n/a |

## Setup

1. **Upload the images** in `images/` to `/wp-content/uploads/lam-ambassadors/`. If you use a different location, find-and-replace `/wp-content/uploads/lam-ambassadors/` in the three snippets.
2. **Site header:** the snippets use the theme's own header and footer. Make sure the header uses the horizontal logo in `images/lam-logo-horizontal.png` (wings + "Little Angel MEDICAL").
3. **Create the three pages** with the URLs above. For each: use a **full-width template** (no sidebar, no content max-width), **hide the page title**, add one WPBakery **Raw HTML** element (not a text block) and paste the whole snippet file.
   - If you use different URLs, find-and-replace `/ambassadors/`, `/ambassadors/apply/` and `/ambassadors/terms/` in the snippets.
4. **Fonts:** the snippets load Montserrat and Open Sans from Google Fonts. If the theme already loads them (or you prefer to enqueue them), delete the two `<link>` lines at the top of each snippet.
5. **Sticky header offset:** anchor links and the terms table of contents assume a sticky site header of up to ~110px. If the header is taller, adjust `scroll-margin-top:110px` (CSS) and `top: 110px` (terms TOC).
6. **Page builders:** if a builder (Elementor, WPBakery, etc.) strips `<script>` or `<style>`, use its HTML/code widget or a page template instead. The user publishing the page needs the `unfiltered_html` capability.

## Prices: one place to edit

At the top of the script in `1-ambassador-page.html`:

```js
var LAM_SETTINGS = {
  annualPrice: 149.99,
  monthlyPrice: 24.99,
  commissionRate: 0.30,
  firstPaymentDiscount: 0.20,
  annualShare: 0.75
};
```

The earnings calculator ("Estimated earnings this month") reads from these values. The page uses the current prices ($149.99/year and $24.99/month) for the calculator, the plan examples and the "How much do I earn?" FAQ. If prices change, update these values and the example text and FAQ to match.

## Application form: connect it to Everflow

The form validates required fields and shows the confirmation message, but **it does not send data anywhere yet**. In `2-apply-page.html`, `lamSubmit()` builds a `data` object and calls `window.lamSendApplication(data)` if it exists, then shows the success message.

**Decision: keep our branded form and send each application to Everflow behind the scenes.**

1. **Server-side handler, not the browser.** Add a small WordPress endpoint (e.g. a REST route in a custom plugin or `functions.php`) that receives the form data. The Everflow API key must stay on the server; never put it in the page.
2. **Create a pending partner in Everflow.** The endpoint calls the Everflow Network API to create a partner (affiliate) with status **pending**, name and email from the form, and the other answers stored as custom fields or notes. Confirm the exact endpoint and field mapping with Everflow's API docs or our account manager.
3. **Email notification.** Also send each application to **ambassadors@littleangelmedical.com** so the team sees it the same day.
4. **Spam protection.** Add a honeypot field or reCAPTCHA/Turnstile and basic rate limiting on the endpoint.
5. **Wire up the front end.** Define `window.lamSendApplication` to POST `data` to the endpoint and return a Promise. On success the confirmation appears; on failure the visitor sees an error and can retry. Example:

```js
window.lamSendApplication = function (data) {
  return fetch('/wp-json/lam/v1/ambassador-application', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(function (r) { if (!r.ok) throw new Error('Submit failed'); });
};
```

6. **Approval flow.** The team reviews pending partners in Everflow. Approving there gives the ambassador their link, offer code, QR code and dashboard.
7. **Test end to end**: a test application should appear as a pending partner in Everflow and arrive by email; the confirmation should only show after a successful submit.

Fields sent (`name` attributes on the inputs): `first_name`*, `last_name`*, `email`*, `organization`, `describes_you`* (+ `describes_you_other`), `website`, `social_handle`, `share_channels[]`* (+ `share_channels_other`), `community_description`, `audience_size`, `agreed_to_terms`* (* required).

Confirmation message (keep as is): "You're on your way to becoming a LAM ambassador. Thank you for your interest in the LAM Ambassador Program. Our team will review your application and be in touch shortly. If approved, you'll receive your unique LAM ambassador link, QR code and everything you need to start sharing LAM with your community."

## Before going live

- [ ] "Last updated" date on the terms page matches the publish date.
- [ ] Form connected to Everflow (pending partner created) plus email notification, tested end to end; the confirmation shows only after a successful submit.
- [ ] All buttons go to `/ambassadors/apply/`; terms links go to `/ambassadors/terms/`.
- [ ] Checked on desktop and phone in portrait and landscape (the snippets include tablet and mobile layouts).
- [ ] Optional: add analytics events on "Become a LAM ambassador" clicks and on successful form submit.
